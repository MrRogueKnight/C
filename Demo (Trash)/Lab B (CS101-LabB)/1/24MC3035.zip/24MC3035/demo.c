/*24MC3035@rgipt.ac.in
B.TECH IN MATHEMATICS AND COMPUTING 
Student Name - PRASHANT RANJAN*/

#include <stdio.h>
int main() //  main function : the execution of program begins
{
printf("Hello World!!"); // Prints on the Output Screen 
return 0;
}